// Name: junyi Zhu
// andrewid: junyizh2

// Package declaration for CMU Mars rover project
package edu.cmu.marsrover;

/**
 * Represents a photo taken by a Mars rover
 * Contains information about when and how the photo was taken
 */
public class Photo {
    // The Martian day (sol) when the photo was taken
    private String sol;
    // Name of the camera that took the photo
    private String cameraName;
    // URL or file path to the actual image
    private String imgSrc;

    /**
     * Constructor to create a new Photo object
     * @param sol The Martian day when photo was taken
     * @param cameraName The name of the rover camera used
     * @param imgSrc The source location of the image
     */
    public Photo(String sol, String cameraName, String imgSrc) {
        this.sol = sol;
        this.cameraName = cameraName;
        this.imgSrc = imgSrc;
    }

    /**
     * @return The Martian day (sol) when photo was taken
     */
    public String getSol() {
        return sol;
    }

    /**
     * @return The name of the camera that took the photo
     */
    public String getCameraName() {
        return cameraName;
    }

    /**
     * @return The source location of the image
     */
    public String getImgSrc() {
        return imgSrc;
    }
}
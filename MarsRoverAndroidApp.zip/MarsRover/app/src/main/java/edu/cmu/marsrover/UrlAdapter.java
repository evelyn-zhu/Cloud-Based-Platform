// Name: junyi Zhu
// andrewid: junyizh2
// Package declaration for CMU Mars rover project
package edu.cmu.marsrover;

// Android imports for UI components and context
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

// AndroidX imports for RecyclerView functionality
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Adapter class for displaying Mars rover photos in a RecyclerView
 * Handles the creation and binding of views for each photo item
 */
public class UrlAdapter extends RecyclerView.Adapter<UrlAdapter.UrlViewHolder> {

    // Context for inflating layouts
    private Context context;
    // List of photo objects to display
    private List<Photo> photoList;

    /**
     * Constructor for the adapter
     * @param context The activity or fragment context
     * @param photoList List of Photo objects to display
     */
    public UrlAdapter(Context context, List<Photo> photoList) {
        this.context = context;
        this.photoList = photoList;
    }

    /**
     * Creates new ViewHolder instances for the RecyclerView
     * @param parent The ViewGroup into which the new View will be added
     * @param viewType The view type of the new View
     * @return A new UrlViewHolder that holds the View for each list item
     */
    @NonNull
    @Override
    public UrlViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_url, parent, false);
        return new UrlViewHolder(view);
    }

    /**
     * Binds data to the ViewHolder at the specified position
     * Sets the sol, camera name, and image URL for each photo item
     * @param holder The ViewHolder to bind data to
     * @param position The position of the item in the data set
     */
    @Override
    public void onBindViewHolder(@NonNull UrlViewHolder holder, int position) {
        Photo photo = photoList.get(position);

        holder.solText.setText("Sol: " + photo.getSol());
        holder.cameraText.setText("Camera: " + photo.getCameraName());
        holder.urlText.setText(photo.getImgSrc());
    }

    /**
     * Returns the total number of items in the data set
     * @return Size of the photo list
     */
    @Override
    public int getItemCount() {
        return photoList.size();
    }

    /**
     * ViewHolder class that holds references to the UI elements for each list item
     * Contains TextViews for displaying sol, camera name, and image URL
     */
    public static class UrlViewHolder extends RecyclerView.ViewHolder {
        TextView solText, cameraText, urlText;

        /**
         * Constructor for the ViewHolder
         * Finds and stores references to the TextViews in the layout
         * @param itemView The View that contains the UI elements
         */
        public UrlViewHolder(@NonNull View itemView) {
            super(itemView);
            solText = itemView.findViewById(R.id.solText);
            cameraText = itemView.findViewById(R.id.cameraText);
            urlText = itemView.findViewById(R.id.urlText);
        }
    }
}
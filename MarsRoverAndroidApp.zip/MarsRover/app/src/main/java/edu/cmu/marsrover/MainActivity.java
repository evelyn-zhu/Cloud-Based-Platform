// Name: junyi Zhu
// andrewid: junyizh2
package edu.cmu.marsrover;

// Necessary Android imports for UI components, logging, and RecyclerView
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

// Importing OkHttp library for making HTTP requests
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

// For handling JSON data
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

// MainActivity class, representing the entry point of the application
public class MainActivity extends AppCompatActivity {

    // UI elements for user interaction and data display
    private EditText solInput; // Input field for entering the "sol" value
    private Button fetchButton; // Button to trigger fetching data
    private RecyclerView recyclerView; // RecyclerView for displaying fetched photos
    private TextView noResultsMessage; // Message displayed when no results are found

    // Adapter and list to manage and display photo data in RecyclerView
    private UrlAdapter urlAdapter;
    private List<Photo> photoList = new ArrayList<>();

    // Base API URL for fetching Mars Rover photos
    private final String BASE_URL = "https://verbose-space-waffle-7xgxq545qqg2x6r-8080.app.github.dev/api/photos";

    // Lifecycle method, called when the activity is created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Linking UI elements to their corresponding IDs in the layout
        solInput = findViewById(R.id.solInput);
        fetchButton = findViewById(R.id.fetchButton);
        recyclerView = findViewById(R.id.recyclerView);
        noResultsMessage = findViewById(R.id.noResultsMessage);

        // Setting up RecyclerView with a LinearLayoutManager and custom adapter
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        urlAdapter = new UrlAdapter(this, photoList);
        recyclerView.setAdapter(urlAdapter);

        // Set a click listener for the fetch button
        fetchButton.setOnClickListener(v -> {
            String sol = solInput.getText().toString().trim(); // Get user input
            if (!sol.isEmpty()) { // Ensure the input is not empty
                fetchPhotos(sol); // Call fetchPhotos method to fetch data
            }
        });
    }

    // Method to fetch photos based on the entered "sol" value
    private void fetchPhotos(String sol) {
        OkHttpClient client = new OkHttpClient(); // Initialize HTTP client
        String url = BASE_URL + "?sol=" + sol; // Construct request URL with the "sol" parameter

        Request request = new Request.Builder().url(url).build(); // Create HTTP GET request
        client.newCall(request).enqueue(new Callback() { // Make asynchronous API call
            @Override
            public void onFailure(Call call, IOException e) {
                // Handle network or request failure
                e.printStackTrace();
                Log.e("API_ERROR", "Failed to fetch photos", e);
                runOnUiThread(() -> { // Update UI on the main thread
                    noResultsMessage.setText("Failed to fetch data. Please try again.");
                    noResultsMessage.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) { // Check if the response is successful
                    String responseData = response.body().string(); // Get response body as a string
                    runOnUiThread(() -> {
                        try {
                            // Parse JSON response
                            JSONObject jsonResponse = new JSONObject(responseData);
                            JSONArray photosArray = jsonResponse.getJSONArray("photos");

                            photoList.clear(); // Clear previous data
                            if (photosArray.length() == 0) {
                                // Display message if no results are found
                                noResultsMessage.setText("No results found for the entered sol.");
                                noResultsMessage.setVisibility(View.VISIBLE);
                                recyclerView.setVisibility(View.GONE);
                            } else {
                                // Populate photoList with data and update UI
                                noResultsMessage.setVisibility(View.GONE);
                                recyclerView.setVisibility(View.VISIBLE);

                                for (int i = 0; i < photosArray.length(); i++) {
                                    JSONObject photo = photosArray.getJSONObject(i);
                                    String solValue = photo.getString("sol"); // Extract "sol" value
                                    String cameraName = photo.getString("camera_name"); // Extract camera name
                                    String imgSrc = photo.getString("img_src").replace("http://", "https://"); // Convert image URL to HTTPS

                                    photoList.add(new Photo(solValue, cameraName, imgSrc)); // Add photo to the list
                                }
                                urlAdapter.notifyDataSetChanged(); // Notify adapter of data changes
                            }
                        } catch (Exception e) {
                            // Handle JSON parsing errors
                            Log.e("JSON_ERROR", "Error parsing JSON", e);
                            noResultsMessage.setText("Failed to parse data. Please try again.");
                            noResultsMessage.setVisibility(View.VISIBLE);
                            recyclerView.setVisibility(View.GONE);
                        }
                    });
                } else {
                    // Handle unsuccessful responses (e.g., 404, 500 errors)
                    runOnUiThread(() -> {
                        noResultsMessage.setText("Error: " + response.code() + ". Please try again.");
                        noResultsMessage.setVisibility(View.VISIBLE);
                        recyclerView.setVisibility(View.GONE);
                    });
                }
            }
        });
    }
}

// Name: Junyi Zhu
// Andrew ID: junyizh2

package edu.cmu.model;

import com.mongodb.client.*;
import com.mongodb.client.model.*;
import org.bson.Document;

import java.util.*;

/**
 * LogDataModel is a utility class for interacting with a MongoDB database to log requests
 * and retrieve log data for analytics purposes.
 */
public class LogDataModel {
    // MongoDB connection string for the project database
    private static final String MONGO_URI = "mongodb+srv://junyizhu24:20021108@cluster0.dfzhn.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

    /**
     * Logs a request by inserting a document into the "logs" collection.
     *
     * @param sol           the solution identifier
     * @param userAgent     the user agent making the request
     * @param ipAddress     the IP address of the request origin
     * @param endpoint      the endpoint that was accessed
     * @param responseTime  the response time of the request in milliseconds
     * @param status        the HTTP status code of the response
     */
    public static void logRequest(String sol, String userAgent, String ipAddress, String endpoint, long responseTime, int status) {
        try (MongoClient mongoClient = MongoClients.create(MONGO_URI)) {
            MongoDatabase database = mongoClient.getDatabase("project4");
            MongoCollection<Document> collection = database.getCollection("logs");

            // Create a log document with relevant request information
            Document log = new Document()
                    .append("timestamp", new Date()) // current timestamp
                    .append("sol", sol)             // solution identifier
                    .append("userAgent", userAgent) // user agent
                    .append("ipAddress", ipAddress) // IP address
                    .append("endpoint", endpoint)   // accessed endpoint
                    .append("responseTime", responseTime) // response time in ms
                    .append("status", status);      // HTTP status code

            // Insert the log document into the collection
            collection.insertOne(log);
        }
    }

    /**
     * Retrieves the total number of logged requests from the "logs" collection.
     *
     * @return the total count of log documents
     */
    public static long getTotalRequests() {
        try (MongoClient mongoClient = MongoClients.create(MONGO_URI)) {
            MongoDatabase database = mongoClient.getDatabase("project4");
            MongoCollection<Document> collection = database.getCollection("logs");

            // Return the total count of documents in the "logs" collection
            return collection.countDocuments();
        }
    }

    /**
     * Retrieves the top 5 most popular solutions based on the number of requests.
     *
     * @return a list of documents representing the most popular solutions and their counts
     */
    public static List<Document> getPopularSols() {
        try (MongoClient mongoClient = MongoClients.create(MONGO_URI)) {
            MongoDatabase database = mongoClient.getDatabase("project4");
            MongoCollection<Document> collection = database.getCollection("logs");

            // Perform an aggregation to group by "sol", count requests, and sort by count in descending order
            return collection.aggregate(Arrays.asList(
                    Aggregates.group("$sol", Accumulators.sum("count", 1)), // Group by "sol" with a count
                    Aggregates.sort(Sorts.descending("count")),            // Sort by count descending
                    Aggregates.limit(5)                                    // Limit to top 5 results
            )).into(new ArrayList<>());
        }
    }

    /**
     * Retrieves the 10 most recent log entries from the "logs" collection.
     *
     * @return a list of documents representing the most recent log entries
     */
    public static List<Document> getRecentLogs() {
        try (MongoClient mongoClient = MongoClients.create(MONGO_URI)) {
            MongoDatabase database = mongoClient.getDatabase("project4");
            MongoCollection<Document> collection = database.getCollection("logs");

            // Query the "logs" collection for the 10 most recent entries
            return collection.find()
                    .sort(Sorts.descending("timestamp")) // Sort by timestamp in descending order
                    .limit(10)                           // Limit to 10 entries
                    .into(new ArrayList<>());
        }
    }
}

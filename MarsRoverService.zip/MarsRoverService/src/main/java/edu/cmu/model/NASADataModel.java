// Name: Junyi Zhu
// Andrew ID: junyizh2
package edu.cmu.model;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * NASADataModel is a utility class for fetching data from NASA's Mars Rover Photos API.
 */
public class NASADataModel {
    // API key for accessing the NASA Mars Rover Photos API
    private static final String NASA_API_KEY = "HKE5lfM3mSIVDHU1gyBpF2myH1aPDJJFOHW7DkLa";

    /**
     * Fetches Mars rover photos from the NASA API for a given sol (Martian day).
     *
     * @param sol the Martian sol (day) for which to fetch photos
     * @return a JSON-formatted string containing the API response
     * @throws IOException if an error occurs while connecting to the API or reading the response
     */
    public static String fetchPhotos(String sol) throws IOException {
        // Construct the API URL with the given sol and API key
        String urlStr = "https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?sol="
                + sol + "&api_key=" + NASA_API_KEY;

        // Create a URL object from the constructed string
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        // Initialize a StringBuilder to hold the API response
        StringBuilder response = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(conn.getInputStream()))) {
            String line;
            // Read the response line by line and append it to the StringBuilder
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
        }
        return response.toString();
    }
}

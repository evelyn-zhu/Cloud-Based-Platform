// Name: Junyi Zhu
// Andrew ID: junyizh2

package edu.cmu.controller;

import edu.cmu.model.NASADataModel;
import edu.cmu.model.LogDataModel;
import org.json.JSONArray;
import org.json.JSONObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;

/**
 * PhotoController is a servlet that handles HTTP GET requests to fetch and filter
 * Mars rover photos from NASA's API and logs the request details.
 */
public class PhotoController extends HttpServlet {

    /**
     * Handles GET requests to fetch filtered Mars rover photos and log request details.
     *
     * @param request  the HttpServletRequest object containing client request information
     * @param response the HttpServletResponse object for sending response data to the client
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an input or output error is detected
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve the sol parameter from the request, default to "1" if not provided
        String sol = request.getParameter("sol");
        if (sol == null || sol.isEmpty()) {
            sol = "1";
        }

        // Record the start time for calculating response time
        long startTime = System.currentTimeMillis();

        try {
            // Fetch data from NASA API
            String nasaData = NASADataModel.fetchPhotos(sol);
            JSONObject nasaResponse = new JSONObject(nasaData);
            JSONArray photos = nasaResponse.getJSONArray("photos");

            // Filter the data to extract relevant fields
            JSONArray filteredPhotos = new JSONArray();
            for (int i = 0; i < photos.length(); i++) {
                JSONObject photo = photos.getJSONObject(i);
                JSONObject filteredPhoto = new JSONObject();
                filteredPhoto.put("img_src", photo.getString("img_src")); // Image URL
                filteredPhoto.put("sol", photo.getInt("sol")); // Martian day (sol)
                filteredPhoto.put("camera_name", photo.getJSONObject("camera").getString("full_name")); // Camera name
                filteredPhotos.put(filteredPhoto);
            }

            // Create a JSON response with the filtered photos
            JSONObject jsonResponse = new JSONObject();
            jsonResponse.put("photos", filteredPhotos);

            // Send the JSON response to the client
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(jsonResponse.toString());
            long responseTime = System.currentTimeMillis() - startTime;

            // Log the request details using LogDataModel
            LogDataModel.logRequest(sol, request.getHeader("User-Agent"), request.getRemoteAddr(),
                    request.getRequestURI(), responseTime, HttpServletResponse.SC_OK);
        } catch (Exception e) {
            // Handle errors and log the failure
            long responseTime = System.currentTimeMillis() - startTime;
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);

            // Create an error JSON response
            JSONObject error = new JSONObject();
            error.put("error", e.getMessage());
            response.getWriter().write(error.toString());

            // Log the failed request details
            LogDataModel.logRequest(sol, request.getHeader("User-Agent"), request.getRemoteAddr(),
                    request.getRequestURI(), responseTime, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
}

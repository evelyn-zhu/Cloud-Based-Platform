// Name: Junyi Zhu
// Andrew ID: junyizh2
package edu.cmu.controller;

import edu.cmu.model.LogDataModel;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;
import org.bson.Document;

/**
 * DashboardController is a servlet responsible for preparing data for the dashboard view.
 * It retrieves log statistics and forwards them to a JSP page for display.
 */
public class DashboardController extends HttpServlet {

    /**
     * Handles GET requests to retrieve log data and forward it to the dashboard JSP.
     *
     * @param request  the HttpServletRequest object containing client request information
     * @param response the HttpServletResponse object for sending response data to the client
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an input or output error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Fetch data from MongoDB using LogDataModel
        long totalRequests = LogDataModel.getTotalRequests(); // Total number of requests
        List<Document> popularSols = LogDataModel.getPopularSols(); // Top 5 popular solutions
        List<Document> recentLogs = LogDataModel.getRecentLogs(); // Most recent log entries

        // Set fetched data as request attributes to be accessible in the JSP
        request.setAttribute("totalRequests", totalRequests);
        request.setAttribute("popularSols", popularSols);
        request.setAttribute("recentLogs", recentLogs);

        // Forward the request and response to the dashboard view (JSP page)
        request.getRequestDispatcher("dashboard.jsp").forward(request, response);
    }
}
